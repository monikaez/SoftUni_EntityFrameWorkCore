﻿namespace MusicHub
{
    using System;

    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            string output = string.Empty;

            //Test 02.Export Albums Info
            //output = ExportAlbumsInfo(context, 9);

            //Test 03.Export Songs Above Duration
            //output = ExportSongsAboveDuration(context, 4);

            Console.WriteLine(output);
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            throw new NotImplementedException();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
