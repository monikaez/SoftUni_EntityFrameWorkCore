﻿

namespace Medicines.Data.Models.Enums;

public enum AgeGroup
{
    Child = 0, 
    Adult, 
    Senior
}
