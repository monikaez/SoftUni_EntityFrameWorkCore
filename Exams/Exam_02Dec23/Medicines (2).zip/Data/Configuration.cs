﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=MedicinesT;Trusted_Connection=True;";
    }
}
