﻿
namespace Cadastre.Data.Enumerations;

public enum Region
{
    SouthEast = 0,
    SouthWest = 1,
    NorthEast = 2,
    NorthWest = 3

}
